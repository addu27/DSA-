import java.util.*;

public class Basic {
    public static void printHelloWorld(){
        System.out.println("Hello World!");
    }

    public static int sum(int num1, int num2){
        int sum = num1+num2;
        return sum;
    }

    public static void swapping(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter value of A : ");
        int a = sc.nextInt();
        System.out.print("Enter value of B : ");
        int b = sc.nextInt();
        int temp;
        temp = a;
        a = b;
        b = temp;
        System.out.println("Value of A is : " + a + "\nValue of B is : " + b);
    }

    public static int factorial(int num){
        int fact = 1;
        for(int i=1;i<=num;i++){
            fact = fact * i;
        }
        return fact;
    }

    public static void binomialCoefficient(int n, int r){
        int a = factorial(n);
        int b = factorial(r);
        int c = factorial(n-r);
        int BC = (a/(b*c));
        System.out.println("Binomial Coefficent is : " + BC);
    }

    public static void main(String[] args) {
//        printHelloWorld();

//        Scanner sc =new Scanner(System.in);
//        int a = sc.nextInt();
//        int b = sc.nextInt();
//        int addition = sum(a,b);
//        System.out.println("Addition is : " + addition );

//        swapping();

//        Scanner sc = new Scanner(System.in);
//        System.out.print("Enter number : ");
//        int n = sc.nextInt();
//        int fact = factorial(n);
//        System.out.println("Factorial is :" + fact);

        // Binomial Coefficient
        binomialCoefficient(5,2);


    }


}
