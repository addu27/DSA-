public class Switch_stat {
    public static void main(String[] args) {
        int num = 12;
        switch (num) {
            case 1:System.out.println("A");
                    break;
            case 2:System.out.println("B");
                    break;
            case 3:System.out.println("C");
                    break;
            case 4:System.out.println("D");
                    break;
            default:System.out.println("Hello");
        }

        int ch = 'a';
        switch (ch) {
            case 'a':System.out.println("A");
                break;
            case 'c':System.out.println("B");
                break;
            case 'd':System.out.println("C");
                break;
            default:System.out.println("Hello");
        }
    }
}
