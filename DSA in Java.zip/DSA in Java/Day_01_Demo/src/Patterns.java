public class Patterns {
    public static void main(String[] args) {
//        for(int i=5;i>=1;i--) {
//            for(int j=i;j<=5;j++) {
//                System.out.print("* ");
//            }
//            System.out.println("");
//        }

        //           or
//        for(int i=1;i<=5;i++) {
//            for(int j=1;j<=i;j++) {
//                System.out.print("* ");
//            }
//            System.out.println();

        // reverse pattern
//        for (int i = 5; i >= 1; i--) {
//            for (int j = 1; j <= i; j++) {
//                System.out.print("* ");
//            }
//            System.out.println();
//        }

//        for (int i = 1; i <= 5; i++) {
//            for (int j = 1; j <= i; j++) {
//                System.out.print(j + " ");
//            }
//            System.out.println();
//        }


//        int n = 4;
//        char ch = 'A';
//        for (int i = 1; i <= 4; i++) {
//            for (int j = 1; j <= i; j++) {
//                System.out.print(ch + " ");
//                ch++;
//            }
//            System.out.println();
//        }

//        hollow_rectangle(5,5);
//        rotated_pyramid(4);
//        inverted_half_pyramid_number(5);
//        floyds_triangle(1);
//        triangle_zero_one_pattern();
//        butteryfly_pattern(6);
//        solid_rhombus(5);
//        hollow_rhombus(5);
        diamond_pattern(4);


    }


    public static void hollow_rectangle(int totRows, int totCols){
        for (int i = 1; i <= totRows; i++){
            for (int j = 1; j <= totCols; j++){
                if (i == 1 || i == totRows || j == 1 || j == totCols){
                    System.out.print("* ");
                }else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }

    public static void rotated_pyramid(int n){
        for (int i = 1; i <= n ; i++){
            for (int j = 1; j <= n-i; j++){
                System.out.print("  ");
            }
            for (int j = 1; j <= i; j++){
                System.out.print("* ");
            }
            System.out.println();
        }
    }

    public static void inverted_half_pyramid_number(int num){
        for (int i=5; i>=num; i--){
            for(int j=1; j<=i;j++){
                System.out.print(j +" ");
                num--;
            }
            System.out.println();
        }
    }

    public static void floyds_triangle(int num){
        for (int i=1;i<=5;i++){
            for (int j=1;j<=i;j++){
                System.out.print(num + " ");
                num++;
            }
            System.out.println();
        }
    }

    public static void triangle_zero_one_pattern(){
        for (int i=1;i<=5;i++){
            for (int j=1;j<=i;j++){
                if((i+j) % 2 == 0){
                    System.out.print("1 ");
                }else{
                    System.out.print("0 ");
                }
            }
            System.out.println();
        }
    }

    public static void butteryfly_pattern(int n){
        for (int i=1;i<=n;i++){
            // stars
            for(int j=1;j<=i;j++){
                System.out.print("* ");
            }
            // spaces
            for(int j=1;j<=(2*(n-i));j++){
                System.out.print("  ");
            }
            // stars
            for(int j=1;j<=i;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
        for (int i=n;i>=1;i--){
            // stars
            for(int j=1;j<=i;j++){
                System.out.print("* ");
            }
            // spaces
            for(int j=1;j<=(2*(n-i));j++){
                System.out.print("  ");
            }
            // stars
            for(int j=1;j<=i;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
    }

    public static void solid_rhombus(int n){
        for(int i=1;i<=n;i++){
            for (int j=1;j<=(n-i);j++){
                System.out.print("  ");
            }
            for(int j=1;j<=n;j++){
                System.out.print("* ");
            }
            System.out.println();

        }
    }

    public static void hollow_rhombus(int n){
        for (int i=1;i<=n;i++){
            for(int j=1;j<=(n-i);j++){
                System.out.print("  ");
            }
            for(int j=1;j<=n;j++){
                if (i==1 || i==n || j==1 || j==n){
                    System.out.print("* ");
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
    }

    public static void diamond_pattern(int n){
        for (int i=1;i<=n;i++){
            for (int j=1;j<=(n-i);j++){
                System.out.print("  ");
            }
            for (int j=1; j<=(2*i)-1; j++){
                System.out.print("* ");
            }
            System.out.println();
        }
        for (int i=n;i>=1;i--){
            for (int j=1;j<=(n-i);j++){
                System.out.print("  ");
            }
            for (int j=1; j<=(2*i)-1; j++){
                System.out.print("* ");
            }
            System.out.println();
        }
    }



}



























