import java.util.Scanner;

public class Loops {
    public static void main(String[] args) {

        // while loop
//        int counter = 1;
//        int sum = 0;
//        while(counter <= 5){
//            sum = sum + counter;
//            counter++;
//        }
//        System.out.println(sum);

        // for loop
//        for (int i = 1; i <= 5; i++) {
//            for (int j = 1; j <= 5; j++) {
//                System.out.print("* ");
//            }
//            System.out.println("");
//        }
//
//        int num = 241005;
//        while(num > 0){
//            int lastDigit = num % 10;
//            System.out.print(lastDigit + " ");
//            num = num / 10;
//        }

//        int n = 270503;
//        int rev = 0;
//        while (n > 0){
//            int lastDigit = n % 10;
//            rev = (rev * 10) + lastDigit;
//            n = n / 10;
//        }
//        System.out.print(rev);

        // do while loop
//        int count = 1;
//        do {
//            System.out.println("Hello");
//            count++;
//        } while (count <= 5);

        // break statement
//        for (int i = 1; i <= 5; i++){
//            if(i == 3){
//                break;
//            }
//            System.out.println(i);
//        }
//        System.out.println("I am out of the loop");

//        Scanner sc = new Scanner(System.in);
//        do{
//            System.out.print("Enter your number : ");
//          int n = sc.nextInt();
//          if(n %  10 == 0){
//              break;
//          }
//          System.out.println(n);
//        } while(true);

//        for (int i = 1; i <= 10; i++){
//            if(i == 3){
//                continue;
//            }
//            System.out.println(i);
//        }

//        Scanner sc = new Scanner(System.in);
//        do{
//            System.out.print("Enter your number : ");
//            int n = sc.nextInt();
//            if(n %  10 == 0){
//                continue;
//            }
//            System.out.println(n);
//        } while(true);
    }
}
