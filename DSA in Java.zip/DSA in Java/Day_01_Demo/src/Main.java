public class Main {
    public static void main(String[] args) {
        /*
        System.out.println("Hello Aditya");
        System.out.print("Hello Aditya\n");
        System.out.print("Hello Aditya\n");

        System.out.println("****");
        System.out.println("***");
        System.out.println("**");
        System.out.println("*");
        */

        int a = 10;
        int b = 20;
        System.out.println(a + b);



    }
}
