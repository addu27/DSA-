import java.util.Scanner;

public class Maths_Operation {
    public static void main(String args []) {
        Scanner sc = new Scanner(System.in);
//        int a = sc.nextInt();
//        int b = sc.nextInt();
//        int sum = a + b;
//        int mult = a * b;
//        System.out.println(sum);
//        System.out.println(mult);

        // Area of circle
        float rad = sc.nextFloat();
        float area = 3.14f * rad * rad;
        System.out.println("Area of cricle is : " + area);
    }
}
