import java.util.*;

public class Input_method {
    public static  void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();    // .nextLine() takes input as whole line
//        String input = sc.next();       // .next() takes input as single word
        System.out.println(input);

        int number = sc.nextInt();       // .nextInt() takes input as Integer number
        System.out.println(number);

        float price = sc.nextFloat();    // .nextFloat() takes input floating number
        System.out.println(price);
    }
}
