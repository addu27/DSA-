import javax.swing.*;

public class ith_bit {

    public static void get_ith_bit(int n, int i){
        int bitMask = (n<<i);
        if ((n & bitMask) == 0){
            System.out.println("0");
        } else {
            System.out.println("1");
        }
    }

    public static void set_ith_bit(int n,int i){
        int bitMask = 1<<i;
        System.out.println(n | bitMask);
    }

    public static int clear_ith_bit(int n,int i){
        int bitMask = 1<<i;
        return n ^ bitMask;
    }

    public static int update_ith_bit(int n,int i,int newBit){
        n = clear_ith_bit(n,i);
        int bitMask = newBit<<i;
        return n | bitMask;
    }

    public static int clear_last_ith_bits(int n,int i){
        int bitMask = (~0)<<i;
        return n & bitMask;
    }

    public static int clear_rangeof_ith_bits(int n,int i,int j){
         int a = ((~0)<<(j+1));
         int b = (1<<i)-1;
         int bitMask = a | b;
         return n & bitMask;
    }

    public static void main(String[] args){
//        get_ith_bit(24,4);
//        set_ith_bit(3,2);
//        System.out.println(clear_ith_bit(15,1));
//        System.out.println(update_ith_bit(10,2,1));
//        System.out.println(clear_last_ith_bits(173,4));
        System.out.println(clear_rangeof_ith_bits(10,2,4));
    }
}
