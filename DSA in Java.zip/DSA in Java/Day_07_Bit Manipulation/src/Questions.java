public class Questions {

    public static boolean num_is_power_of_two(int n){
        // check the number is power of two
        return (n & (n-1)) == 0;
    }

    public static int count_set_bits(int n){
        // Count set btis in a number
        int count =0;
        while(n > 0){
            if ((n & 1) != 0){
                count++;
            }
            n = n>>1;
        }

        return count;
    }

    public static int fast_exponentiation(int a, int n){
        int ans = 1;
        while (n > 0){
            if ((n & 1) != 0){
                ans = ans * a;
            }
            a = a * a;
            n = n>>1;
        }

        return ans;
    }

    public static void main(String[] args){
//        System.out.println(num_is_power_of_two(128));
//        System.out.println(count_set_bits(10));
        System.out.println(fast_exponentiation(5,3));


        int a = 5, b = 10;
        a = b ;

    }

}
