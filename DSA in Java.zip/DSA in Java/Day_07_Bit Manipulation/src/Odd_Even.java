public class Odd_Even {

    public static void oddOrEveb(int n) {
        int bitMask = 1;
        if((n & bitMask) == 0){
            System.out.println("Even number");
        } else {
            System.out.println("Odd number");
        }
    }

    public static void main(String[] args) {
        oddOrEveb(79);
    }
}
