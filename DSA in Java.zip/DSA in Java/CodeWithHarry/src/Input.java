import java.util.Scanner;

public class Input {

    public static void main(String [] args){
//        System.out.print("Enter number : ");
        Scanner s = new Scanner(System.in);
//        int a = s.nextInt();
//        boolean b = s.hasNextInt();
//        System.out.println(b);
//        System.out.println(a);

        String str = s.next();
        System.out.println(str);

//        String str = s.nextLine();
//        System.out.println(str);
    }
}