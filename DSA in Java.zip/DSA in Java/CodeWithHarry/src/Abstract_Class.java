
abstract class Base1{
    Base1(){
        System.out.println("I am constructor of Base2");
    }

    public void sayHello(){
        System.out.println("Hello");
    }
    abstract public void greet();
    abstract public void greet2();
}

class Child2 extends Base1{
    public void greet(){
        System.out.println("Good Morning");
    }
    public void greet2(){
        System.out.println("Good Night");
    }
}

public class Abstract_Class {
    public static void main(String[] args) {
        // Base1 b = new Base1();  --- error
        Child2 c = new Child2();
    }
}
