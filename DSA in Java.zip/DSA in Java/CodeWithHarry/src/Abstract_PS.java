
abstract class Pen{
    abstract void Write();
    abstract void Refill();
}

class Func extends Pen{
    void ChangeNib(){
        System.out.println("Changing the nib");
    }
    public void Write(){
        System.out.println("Writing...");
    }
    public void Refill(){
        System.out.println("Refilling...");
    }

}

class Monkey{
    public void jump(){
        System.out.println("Jumping");
    }
    public void bite(){
        System.out.println("Biting");
    }
}

interface BasicAnimal{
    void eat();
    void sleep();
}

class Human extends Monkey implements BasicAnimal{
    void speak(){
        System.out.println("Hello");
    }
    public void eat(){
        System.out.println("Eating");
    }
    public void sleep(){
        System.out.println("Sleeping");
    }
}




public class Abstract_PS {
    public static void main(String[] args) {
//        Func f = new Func();
//        f.Refill();
//        f.Write();
//        f.ChangeNib();

        Human h = new Human();
        h.jump();
        h.sleep();
        h.speak();

        BasicAnimal ba = new Human();
        // ba.speak();   ----> error
    }
}
