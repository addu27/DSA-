/*           Create a class Game, Which allows a user to play "Guess the Number"
            game once. Same should have the following methods,
            1. Constructor to generate the random number
            2. takeUserInput() to take a user input of number
            3. isCorrectNumber() to detect whether the number entered by the user
               is true,
            Use the properties such as noOfGuesses(int), etc to get this task done!
        */

import java.util.Scanner;

class Guess{
    int randomNum;
    int g;

    public Guess(){
        randomNum = (int) (Math.random() * 50) +1;
    }

    public void takeUserInput(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your Guess : ");
        g = sc.nextInt();
    }

    public void check (){
        while(randomNum  != g){
            takeUserInput();
            if(randomNum < g){
                System.out.println("Your guess was larger");
            } else if (randomNum > g) {
                System.out.println("Your guess was smaller");
            }else {
                System.out.println("Congratulations, Your guess is correct");
            }
        }
    }
}

public class GuesstheNumber {

    public static void main(String[] args) {

        Guess guessNum = new Guess();
        guessNum.takeUserInput();
        guessNum.check();
    }
}
