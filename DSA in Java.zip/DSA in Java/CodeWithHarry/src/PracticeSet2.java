import java.util.Scanner;

public class PracticeSet2 {

    public static void main(String[] args) {
        float a  = (float) 7 / 4 * 9 / 2;
        System.out.println(a);

        char grade = 'B';
        // Encrypt grade
        grade = (char) (grade + 8);
        System.out.println(grade);

        // Decrypt grade
        grade = (char) (grade - 8);
        System.out.println(grade);

        // use of comparison operator
        int b = 10;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number : ");
        int c = sc.nextInt();
        System.out.println(b > c);

        int num1 = 10;
        float num2 = 15.167f;
        System.out.printf("The value of a is %d and value of b is %f", num1, num2);
    }
}
