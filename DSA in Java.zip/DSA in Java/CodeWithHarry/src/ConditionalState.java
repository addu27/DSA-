import java.util.Scanner;

public class ConditionalState {

    public static void main(String[] args) {
        int age;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your age : ");
        age = sc.nextInt();

        switch (age){
            case 18:
                System.out.println("You are going to become an adult");
                break;

            case 60:
                System.out.println("You are going to retired");
                break;

            case 40:
                System.out.println("You are experienced");
                break;

            default:
                System.out.println("Enjoy your life");
        }
        System.out.println("Thank you!");


    }
}
