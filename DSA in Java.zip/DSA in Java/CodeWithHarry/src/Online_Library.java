
/*
    You have to implement the library using Java class Library
    Methods : addBook, issueBook, returnBook, showAvailableBooks
    Properties : Array to store the available books
    Array to store the issued books
*/

import java.util.ArrayList;
import java.util.List;

class Library{
    List<String> availableBook = new ArrayList<>();
    List<String> issued = new ArrayList<>();

    public void addBook(String bookName){
        availableBook.add(bookName);
        System.out.println("Book added : " + bookName);
    }

    public void issueBook(String bookName){
        if (availableBook.contains(bookName)){
            availableBook.remove(bookName);
            issued.add(bookName);
            System.out.println("Book issued : " + bookName);
        } else {
            System.out.println("Sorry, Book is not available");
        }
    }

    public void returnBook(String bookName){
        if (issued.contains(bookName)){
            issued.remove(bookName);
            availableBook.add(bookName);
            System.out.println("Book returned : " + bookName);
        } else {
            System.out.println("This book was not issued by library");
        }
    }

    public void showAvailableBook(){
        if (availableBook.isEmpty()){
            System.out.println("Book are not available");
        } else {
            System.out.println("Available books : ");
            for (String book : availableBook){
                System.out.println(" - " + book);
            }
        }
    }
}

public class Online_Library {

    public static void main(String[] args) {
        Library l = new Library();
        l.addBook("Marathi");
        l.addBook("SocialSci");
        l.addBook("Maths");
        l.addBook("English");

        l.showAvailableBook();
        l.issueBook("English");

        l.issueBook("Phy");

        l.returnBook("English");
    }
}
