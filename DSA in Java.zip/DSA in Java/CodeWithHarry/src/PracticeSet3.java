import java.util.Scanner;

public class PracticeSet3 {

    public static void main(String[] args) {
        int maths, science, english;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter English marks : ");
        english = sc.nextInt();
        System.out.print("Enter Maths marks : ");
        maths = sc.nextInt();
        System.out.print("Enter Science marks : ");
        science = sc.nextInt();

        float avg = (maths + science + english) / 3.0f;

        if(maths > 33 && english > 33 && science > 33 && avg >= 40) {
            System.out.println("You are pass!");
        }
        else {
            System.out.println("You are fail!");
        }
    }
}
