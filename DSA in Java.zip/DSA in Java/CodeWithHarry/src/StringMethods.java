public class StringMethods {

    public static void main(String[] args) {
        String str = "Aditya";
        System.out.println(str.toUpperCase());
        String str2 = str.toUpperCase();
        System.out.println(str2);
        String nonTrimmedStr = "     Aditya        ";
        System.out.println(nonTrimmedStr);
        String trimmedStr = nonTrimmedStr.trim();
        System.out.println(trimmedStr);

        System.out.println(str.startsWith("Adi"));
        System.out.println(str.endsWith("ya"));

        String name = "Aditya Gaikwad";
        System.out.println(name.indexOf("aGa",4));
        System.out.println(name.indexOf("aGa",6));
        System.out.println(name.equalsIgnoreCase("adityagaikwad"));

        System.out.println("I am escape sequence \" double quote");
        System.out.println(name.replace(" ","_"));

        String letter = "Dear <|name|>, thanks a lot !";
        letter = letter.replace("<|name|>","Aditya");
        System.out.println(letter);

        String myStr = "This string contains Double  and Triple spaces";
        System.out.println(myStr.indexOf("  "));
        System.out.println(myStr.indexOf("   "));

        String myLetter = "Dear Harray, \n\tThis course is nice, \n\tThanks!";
        System.out.println(myLetter);
    }
}
