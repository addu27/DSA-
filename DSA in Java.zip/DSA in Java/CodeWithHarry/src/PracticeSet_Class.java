
class Employee1{
    int salary;
    String name;

    public int getSalary(){
        return salary;
    }

    public String getName(){
        return name;
    }

    public void setName(String newName){
        name = newName;
    }
}

class cellPhone{

    public void ring(){
        System.out.println("Ringing...");
    }

    public void vibrate(){
        System.out.println("vibrating...");
    }

    public void call() {
        System.out.println("calling...");
    }
}

class Square{
    int side;

    public int area(){
        return side*side;
    }

    public int perimeter(){
        return side * 4;
    }
}

class Rectangle{
    int length, breadth;

    public int square(){
        return length * breadth;
    }

    public int perimeter() {
        return (2*length)+(2*breadth);
    }
}

public class PracticeSet_Class {

    public static void main(String[] args) {
        /*
        // Problem 1
        Employee1 a = new Employee1();
        a.salary = 15000;
        a.setName("Aditya");
        System.out.println(a.getSalary());
        System.out.println(a.getName());
        */

        /*
        // Problem 2
        cellPhone samsung = new cellPhone();
        samsung.call();
        samsung.vibrate();
        samsung.ring();
        */

        /*
        // Problem 3
        Square s = new Square();
        s.side = 10;
        System.out.println(s.area());
        System.out.println(s.perimeter());
        */

        /*
        // Problem 4
        Rectangle r = new Rectangle();
        r.breadth = 5;
        r.length = 7;
        System.out.println(r.perimeter());
        System.out.println(r.square());
        */

        // Problem 5



    }
}
