class Student{
    private int id;
    private String name;

    public void setName(String n){
        name = n;
    }

    public void setId(int i){
        id = i;
    }

    public int getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    // constructor
    public Student(){
        id = 45;
        name = "your_name";
    }

    public Student(String myName, int myId){
        id = myId;
        name = myName;
    }
}

public class GetterSetter {

    public static void main(String[] args) {
        Student s1 = new Student("Aditya",12);

        // setters
        // s1.setId(11);
        // s1.setName("Abc");

        // getters
        System.out.println(s1.getId());
        System.out.println(s1.getName());


    }
}
