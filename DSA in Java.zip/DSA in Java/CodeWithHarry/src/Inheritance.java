
class Base{
    int x;

    public void setX(int x) {
        // System.out.println("I am in Base and setting X now");
        this.x = x;
    }
    public int getX(){
        return x;
    }

    Base(){
        System.out.println("I am a Base class constructor");
    }
    Base(int a){
        System.out.println("I am a Base class constructor with a value : " + a);
    }
}

class Derived extends Base{
    int y;

    public void setY(int y) {
        // System.out.println("I am in Derived and setting Y now");
        this.y = y;
    }
    public int getY(){
        return y;
    }

    Derived(){
//        super(0);
        System.out.println("I am a derived class constructor");
    }
    Derived(int x, int y){
        super(x);
        System.out.println("I am a derived class constructor with a value of x and y as " + x +" & " + y);
    }
}

class ChildofDerived extends Derived{
    ChildofDerived(){
        System.out.println("I am a child of derived constructor");
    }
    ChildofDerived(int x, int y, int z){
        super(x,y);
        System.out.println("I am a ChildofDerived class constructor with a value of z : " + z);
    }
}


class EkClass{
    int a;

    EkClass(int v){
        this.a = v;
    }

    public int getA(){
        return a;
    }

}

class DoClass extends EkClass{
    DoClass(int c){
        super(c);
        System.out.println("Mai ek constructor hoon ");
    }
}

public class Inheritance {

    public static void main(String[] args) {
//        Base b = new Base();
        // b.setX(5);
        // System.out.println(b.getX());

//        Derived d = new Derived();
//        Derived d1 = new Derived(5,20);
        // d.setY(45);
        // System.out.println(d.getY());

//        ChildofDerived ch = new ChildofDerived(5,10,15);

        EkClass ek = new EkClass(65);
        System.out.println(ek.getA());
        DoClass d = new DoClass(5);
        System.out.println(ek.getA());


    }
}
