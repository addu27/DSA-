
class Employee{
    int id;
    int salary;
    String name;

    public void printDetails(){
        System.out.print("My id is " + id);
        System.out.println(" and my name is " + name);
    }

    public int getSalary(){
        return salary;
    }
}

public class OOPs {

    public static void main(String[] args) {
        System.out.println("This is our custom class");
         Employee aditya = new Employee();   // object created
         Employee abc = new Employee();   // object created

         // setting attributes
         aditya.id = 12;
         aditya.salary = 35000;
         aditya.name = "Aditya";

         abc.id = 15;
         abc.salary = 12000;
         abc.name = "Abc";

        // printing the attributes
        // System.out.println(aditya.id);
        // System.out.println(aditya.name);

        aditya.printDetails();
        abc.printDetails();
        int salary = abc.getSalary();
        System.out.println(salary);



    }
}
