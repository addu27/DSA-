import jdk.jfr.Percentage;

import java.util.Scanner;

public class CalcPercentage {

    public static void main(String[] args) {
//        float perc;
//        Scanner sc = new Scanner(System.in);
//        System.out.print("Subject 1 : ");
//        int sub1 = sc.nextInt();
//        System.out.print("Subject 2 : ");
//        int sub2 = sc.nextInt();
//        System.out.print("Subject 3 : ");
//        int sub3 = sc.nextInt();
//        System.out.print("Subject 4 : ");
//        int sub4 = sc.nextInt();
//        System.out.print("Subject 5 : ");
//        int sub5 = sc.nextInt();
//
//        perc = (float) (sub1 + sub2 + sub3 + sub4 + sub5) / 5;
//        System.out.println("Percentage : " + perc + "%");

        // calculate CGPA
        int a = 50;
        int b = 80;
        int c = 65;
        float avg = (float) (a+b+c) / 3;
        System.out.println(avg / 10);
    }
}
