import java.util.*;

// We are given an infinite supply of denominations [1,2,5,10,20,50,100,500,2000].Find min no. of coins/notes to make change for a value V.

public class Indian_Coins {

    public static void main(String[] args){
        int amount = 590;
        int count = 0;
        Integer coins[] = {1,2,5,10,20,50,100,500,2000};

        Arrays.sort(coins, Comparator.reverseOrder());

        ArrayList<Integer> ans = new ArrayList<>();

        // {2000,500,100,50,20,10,5,2,1}
        for (int i=0;i <coins.length;i++){

            if (coins[i] <= amount){

                while (coins[i] <= amount){
                    count++;
                    ans.add(coins[i]);
                    amount = amount - coins[i];
                }
            }

        }

        System.out.println("Notes required : " + count);
        for (int i=0;i< ans.size();i++){
            System.out.print(ans.get(i) + " ");
        }
        System.out.println();
    }
}
