public class Find_subset {

    public static void printSubstring(String str, String ans, int i){
        if (i == str.length()){
            if (ans.isEmpty()){
                System.out.println("null");
            } else {
                System.out.println(ans);
            }
            return;
        }

        // if YES
        printSubstring(str, ans + str.charAt(i), i+1);

        // if NO
        printSubstring(str,ans,i+1);
    }


    public static void main(String[] args){
        String str = "abcd";
        String ans = "";
        printSubstring(str,ans,0);
    }
}
