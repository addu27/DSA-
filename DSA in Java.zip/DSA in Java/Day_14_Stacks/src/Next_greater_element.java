import java.util.*;

// Next greater element

public class Next_greater_element {

    public static void nextGreater(int arr[], int nextGret[], Stack<Integer> s){

        int n = arr.length-1;
        for (int i = n; i >= 0; i--){
            // while loop
            while (!s.isEmpty() && arr[s.peek()] <= arr[i]){
                s.pop();
            }
            // if-else
            if (s.isEmpty()) {
                nextGret[i] = -1;
            }
            else {
                nextGret[i] = arr[s.peek()];
            }
            // push in s
            s.push(i);
        }
    }

    public static void print(int nexGreat[]){
        for (int i=0;i< nexGreat.length;i++){
            System.out.print(nexGreat[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args){
        int arr[] = {6,8,0,1,3};
        Stack<Integer> s = new Stack<>();
        int nextGreat[] = new int[arr.length];

        nextGreater(arr, nextGreat, s);
        print(nextGreat);
    }

}
