import java.util.*;

// Find the duplicate parenthesis form the expression if exist then return true

public class Duplicate_Parenthesis {

    public static boolean duplicateParenthesis(String str){
        Stack<Character> s = new Stack<>();
        for (int i=0;i<str.length();i++){
            char ch = str.charAt(i);

            // closing
            if (ch == ')'){
                int count = 0;
                while (s.peek() != '('){
                    s.pop();
                    count++;
                }
                if (count < 1){
                    return true;  // duplicate
                } else {
                    s.pop();  // opening pair
                }
            } else {
                // opening
                s.push(ch);
            }
        }
        return false;

    }

    public static void main(String[] args){
        String str = "((a+b)(c+d))";
        Stack<Character> s = new Stack<>();

        System.out.println(duplicateParenthesis(str));

    }
}
