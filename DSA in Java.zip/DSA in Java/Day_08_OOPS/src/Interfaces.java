public class Interfaces {

    public static void main(String[] args){
        Quees q = new Quees();
        q.moves();
        King k = new King();
        k.moves();
    }
}

interface ChessPlayer{
    void moves();
}

class Quees implements ChessPlayer{
    public void moves(){
        System.out.println("up, down, right, left, diagonal(in all 4 directiob)");
    }
}

class Rook implements ChessPlayer{
    public void moves(){
        System.out.println("up, down, right, left");
    }
}

class King implements ChessPlayer{
    public void moves(){
        System.out.println("up, down, right, left, diagonal - only one step");
    }
}

