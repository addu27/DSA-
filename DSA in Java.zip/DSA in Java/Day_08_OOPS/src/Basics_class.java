public class Basics_class {

    public static void main(String[] args){
        pen p1 = new pen(); // created a pen object called p1
        p1.setColor("Blue");
        // or
        p1.setColor("Yellow");
        System.out.println(p1.getColor());
        p1.setTip(5);
        System.out.println(p1.getTip());

        BankAccount myAcc = new BankAccount();
        myAcc.username = "Aditya";
        myAcc.setPassword("abcd");

    }

}

class pen{
    private String color;
    private int tip;


    // setter
    void setColor(String newColor){
        color = newColor;
    }
    // setter
    void setTip(int newTip){
        tip = newTip;
    }

    // getters
    String getColor(){
        return this.color;
    }
    // getter
    int getTip(){
        return  this.tip;
    }
}

class BankAccount{
    public String username;
    private String password;

    public void setPassword(String pwd){
        password = pwd;
    }
}
