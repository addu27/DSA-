public class Method_overriding {

    public static void main(String[] args){
        Cat c1 = new Cat();
        c1.eat();
    }
}

class Animal2{
    void eat(){
        System.out.println("Eats");
    }
}

class Cat extends Animal{
    void eat(){
        System.out.println("Cat eats");
    }
}

