
// import java.util.PriorityQueue;


// // We are given N points in a 2D plane which are locations of N cars. If we are at the origin, print the nearest k cars.

// public class Nearby_Cars {
 
//     static class Point implements Comparable<Point>{
//         int x, y, distSq, idx;

//         public Point(int x, int y, int distSq, int idx){
//             this.x = x;
//             this.y = y;
//             this.distSq = distSq;
//             this.idx = idx;
//         }

//         @Override
//         public int compareTo (Point p2){
//             return this.distSq - p2.distSq; // ascending order sorting
//         }
//     }
    
//     public static void main(String[] args) {
//         int pts[][] = {{3, 3},{5, -1},{-2, 4}};
//         int k = 2;

//         PriorityQueue<Point> pq = new PriorityQueue<>();
//         for(int i=0;i<pts.length;i++){
//             int distSq = (pts[i][0]*pts[i][0]) + (pts[i][1]*pts[i][1]);
//             pq.add(new Point(pts[i][0], pts[i][1], distSq, i));
//         }

//         // nearest k cars
//         for(int i=0;i<k;i++){
//             System.out.print("C" + pq.remove().idx+ " ");
//         }
//         System.out.println();
//     }
// }


import java.util.Scanner;

class Main {
    public void helper_function() {
        Scanner sc = new Scanner(System.in);
        int n;
        n = sc.nextInt();
        int[] edges = new int[n];

        for (int i = 0; i < n; i++) {
            edges[i] = sc.nextInt();
        }

        int maxCycleLength = findLargestCycleLength(edges);
        System.out.println(maxCycleLength);
    }

    public int findLargestCycleLength(int[] edges) {
        int maxCycleLength = -1;
        boolean[] visited = new boolean[edges.length];

        for (int i = 0; i < edges.length; i++) {
            if (!visited[i]) {
                int current = i;
                int cycleLength = 0;
                int start = i;

                while (true) {
                    visited[current] = true;
                    current = edges[current];
                    cycleLength++;

                    if (current == start) {
                        maxCycleLength = Math.max(maxCycleLength, cycleLength);
                        break;
                    }

                    if (current == -1 || visited[current]) {
                        break;
                    }
                }
            }
        }

        return maxCycleLength;
    }

    public static void main(String[] args) {
        Main m = new Main();
        m.helper_function();
    }
}ṇ