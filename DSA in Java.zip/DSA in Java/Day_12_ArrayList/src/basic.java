import java.util.*;

public class basic {

    public static void main(String[] args) {
        // java collection framework
        ArrayList<Integer> list = new ArrayList<>();
        ArrayList<String> list2 = new ArrayList<>();
        ArrayList<Boolean> list3 = new ArrayList<>();


        // Operations on ArrayList

        // ADD operation
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        list.add(5);
        list.add(1,7);
        System.out.println(list);

        // GET operation
        System.out.println(list.get(1));

        // Remove element
        System.out.println(list.remove(3));
        System.out.println(list);


        // SET element at index
        list.set(2,10);
        System.out.println(list);


        // Contains element in Arraylist
        System.out.println(list.contains(6));
        System.out.println(list.contains(5));


        // size function
        System.out.println(list.size());


    }
}