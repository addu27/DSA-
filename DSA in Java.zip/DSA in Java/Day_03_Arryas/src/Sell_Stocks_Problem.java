import java.util.*;

public class Sell_Stocks_Problem {

    public static int Buy_Sell_Stocks(int price[]){
        int buyPrice = Integer.MAX_VALUE;
        int sellingPrice = 0;
        int maxProfit = 0;
        for (int i=0;i<price.length;i++){
            if (buyPrice < price[i]){ // profit
                int profit = price[i] - buyPrice; // today's profit
                maxProfit = Math.max(maxProfit, profit);
            } else{
                buyPrice = price[i];
            }
        }
        System.out.println("Buy Price : " +buyPrice);
        return maxProfit;
    }

    public static void main(String[] args) {
        int prices[] = {7,1,5,3,6,4};

        System.out.println("Maximun profit : " + Buy_Sell_Stocks(prices));
    }
}
