public class ArrayOperation {

    public static void reverse(int num[]){
        int first = 0, last = num.length - 1;
        while(first < last){
            int temp = num[first];
            num[first] = num[last];
            num[last] = temp;
            first++;
            last--;
        }

    }

    public static void PairsInArray(int num[]){
        int tp =0;
        for (int i=0;i<num.length;i++){
            int curr = num[i];
            for (int j=i+1;j<num.length;j++){
                System.out.print("(" + curr + "," + num[j] + ")");
                tp++;
            }
            System.out.println();
        }
        System.out.print("Total pairs : " + tp);
    }

    public static void subArrays(int num[]){
        int ts = 0;
        for (int i=0;i<num.length;i++){
//            int start = i;
            for (int j=i;j<num.length;j++){
//                int end = j;
                for (int k=i;k<=j;k++){
                    System.out.print(num[k] + " ");
                }
                ts++;
                System.out.println();
            }
            System.out.println();
        }
        System.out.println("Total subarrays are " +ts);
    }

    public static void maxSubArraySum(int num[]){
        int currSum = 0;
        int maxSum = Integer.MIN_VALUE;

        for (int i=0;i<num.length;i++){
//            int start = i;
            for (int j=i;j<num.length;j++){
//                int end = j;
                currSum = 0;
                for (int k=i;k<=j;k++){
//                    System.out.print(num[k] + " ");
                    currSum = currSum + num[k];
                }
                System.out.println(currSum );
                if (maxSum < currSum){
                    maxSum = currSum;
                }
            }
        }
        System.out.println("Max sum = " +maxSum );
    }

    public static void maxSubArraySum_byPrefixSum(int num[]){
        int currSum = 0;
        int maxSum = Integer.MIN_VALUE;
        int prefix[] = new int[num.length];

        prefix[0] = num[0];
        // calculate prefix array
        for (int i=1;i<prefix.length;i++){
            prefix[i] = prefix[i-1] + num[i];
        }
        for (int i=0;i<num.length;i++){
            int start = i;
            for (int j=i;j<num.length;j++){
                int end = j;

                currSum = start == 0 ? prefix[end] : prefix[end] - prefix[start - 1];

                if (maxSum < currSum){
                    maxSum = currSum;
                }
            }
        }
        System.out.println("Max sum = " +maxSum );
    }

    public static void maxSubArraySum_byKadaneAlgo(int num[]){
        int ms = Integer.MIN_VALUE;
        int cs = 0;

        for (int i=0;i<num.length;i++){
            cs = cs + num[i];
            if(cs < 0){
                cs = 0;
            }
            ms = Math.max(cs, ms);
        }
        System.out.println("Max subarray sum is " + ms);
    }

    public static void main(String[] args){
        int num[] = {2,4,6,8,10};
        int num2[] = {1,-2,6,-1,3};
        int num3[] = {1,-2,4,3};

//        reverse(num);
//        for (int i=0;i<num.length;i++){
//            System.out.print(num[i] + " ");
//        }
//        System.out.println();

//        PairsInArray(num);

//        subArrays(num);

//        maxSubArraySum(num2);

//        maxSubArraySum_byPrefixSum(num2);

//        maxSubArraySum_byKadaneAlgo(num2);

    }
}
