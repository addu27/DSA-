import java.util.*;

public class Basic{

    public static void main(String[] args){
        int marks[] = new int[10];
//        int numbers[] = {1,2,3};
//        String chars[] = {"aa","bb","cc"};

        Scanner sc = new Scanner(System.in);
        marks[0] = sc.nextInt();
        marks[1] = sc.nextInt();
        marks[2] = sc.nextInt();

        System.out.println("Phy : " + marks[0] + "\nChem : " + marks[1] + "\nMaths : " + marks[2]);
        float percentage = (marks[0] + marks[1] + marks[2]) / 3;
        System.out.println("Percentage : " + percentage + "%");
    }
}

