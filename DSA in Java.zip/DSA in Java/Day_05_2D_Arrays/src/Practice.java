public class Practice {

    public static void question_1(int arr[][],int key){
        int count=0;
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[0].length;j++){
                if (arr[i][j]==key){
                    count++;
                }
            }
        }
        System.out.println(key + " present in array " + count + " times");
    }

    public static void question_2(int arr[][]){
        int sum = 0;
        for(int i=0;i<arr[0].length;i++){
            sum+=arr[1][i];
        }
        System.out.println("Sum of 2nd row is " + sum);
    }

    public static void question_3(int arr[][]){


        for (int i=0;i<arr.length;i++){
            for (int j=0;j<arr[0].length;j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
//        int arr[][] = { {4,7,8},{8,8,7} };
//        question_1(arr,7);

//        int arr2[][] = { {1,4,9},{11,4,3},{2,2,3} };
//        question_2(arr2);

//        int arr3[][] =  { {4,7,8},{8,8,7} };
//        int row = 3, col = 2;
//        int transpose[][] = new int[col][row];
//        for (int i=0;i< row;i++){
//            for (int j=0;j<col;j++) {
//                transpose[j][i] = arr3[i][j];
//            }
//        }
//        question_3(arr3);

    }
}
