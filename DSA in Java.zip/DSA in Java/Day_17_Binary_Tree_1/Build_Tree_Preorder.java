import java.util.*;

public class Build_Tree_Preorder {
    
    static class Node{
        int data;
        Node left;
        Node right;

        Node (int data){
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    static class BinaryTree{
        static int idx = -1;

        public static Node buildTree(int nodes[]){
            idx++;

            if(nodes[idx] == -1){
                return null;
            }

            Node newNode = new Node(nodes[idx]);
            newNode.left = buildTree(nodes);
            newNode.right = buildTree(nodes);

            return newNode;
        }

        // preorder traversal
        public static void preorder(Node root){
            if (root == null) {
                System.out.print(-1 + " ");
                return;
            }

            System.out.print(root.data + " ");
            preorder(root.left);
            preorder(root.right);
        }

        // Inorder traversal
        public static void inorder(Node root){
            if (root == null) {
                System.out.print(-1 + " "); 
                return;
            }
            inorder(root.left);
            System.out.print(root.data + " ");   
            inorder(root.right);

        }

        // postorder traversal
        public static void postorder(Node root){
            if (root == null) {
                return;
            }
            
            postorder(root.left);
            postorder(root.right);
            System.out.print(root.data + " ");
        }

        // level order traversal
        public static void levelOrder(Node root){
            if(root == null){
                return;
            }
            Queue<Node> q = new LinkedList<>();
            q.add(root);
            q.add(null);

            while(!q.isEmpty()){
                Node currNode = q.remove();
                if(currNode == null){
                    System.out.println();
                    if(q.isEmpty()){
                        break;
                    } else{
                        q.add(null);
                    }
                } else{
                    System.out.print(currNode.data +  " ");
                    if(currNode.left != null){
                        q.add(currNode.left);
                    } 
                    if(currNode.right != null){
                        q.add(currNode.right);
                    }
                }
                
            }

        }

        // height of tree
        public static int height(Node root){
            if(root == null){
                return 0;
            }
            int lh = height(root.left);
            int rh = height(root.right);
            int height = Math.max(rh, lh) + 1;

            return height;
        }

        // count of node in a tree
        public static int count(Node root){
            if(root == null){
                return 0;
            }

            int lc = count(root.left);
            int rc = count(root.right);
            int c = (lc + rc) + 1;

            return c;
        }

        // sum of nodes
        public static int sum(Node root){
            if(root == null){
                return 0;
            }

            int ls = sum(root.left);
            int rs = sum(root.right);
            int s = ls + rs + root.data;

            return s;
        }

        // Diameter of tree
        public static int diameter(Node root){  // O(n^2)
            if(root == null){
                return 0;
            }

            int leftDiam = diameter(root.left);
            int leftHig = height(root.left);
            int rightDiam = diameter(root.right);
            int rightHig = height(root.right);

            int selfDiam = leftHig + rightHig + 1;

            return Math.max(selfDiam, Math.max(leftDiam, rightDiam));
        }

        // optimized diameter of tree

        static  class Info{
            int diam;
            int ht;

            public Info(int diam, int ht){
                this.diam = diam;
                this.ht = ht;
            }
        }

        public static Info optimizedDiam(Node root){
            if(root == null){
                return new Info(0, 0);
            }

            Info leftInfo = optimizedDiam(root.left);
            Info rightInfo = optimizedDiam(root.right);

            int diam = Math.max(Math.max(leftInfo.diam, rightInfo.diam), leftInfo.ht + rightInfo.ht + 1);

            int ht = Math.max(leftInfo.ht, rightInfo.ht) + 1;

            return new Info(diam, ht);
        }


        // find subroot of tree
        public static boolean isIdentical(Node node, Node subRoot){
            if(node == null && subRoot == null){
                return true;
            } else if(node == null || subRoot == null || node.data != subRoot.data){
                return false;
            }

            if(!isIdentical(node.left, subRoot.left)){
                return false;
            }
            if(!isIdentical(node.right, subRoot.right)){
                return false;
            }

            return true;
        }

        public static boolean isSubtree(Node root, Node subRoot){
            if(root == null){
                return false;
            }

            if(root.data == subRoot.data){
                if(isIdentical(root, subRoot)){
                    return true;
                }
            }

            return isSubtree(root.left, subRoot) || isSubtree(root.right, subRoot);
        }




    }


    public static void main(String[] args) {
        int nodes[] = {1,2,4,-1,-1,5,-1,-1,3,-1,6,-1,-1};

        BinaryTree tree  = new BinaryTree();
        Node root = tree.buildTree(nodes);
        // System.out.println(root.data);

        // tree.preorder(root);
        // tree.inorder(root);
        // tree.postorder(root);
        // tree.levelOrder(root);
        // System.out.println(tree.height(root));
        // System.out.println(tree.count(root));
        // System.out.println(tree.sum(root));
        // System.out.println(tree.diameter(root));
        // System.out.println(tree.optimizedDiam(root).diam);

        Node subRoot = new Node(2);
        subRoot.left = new Node(4); 
        subRoot.right = new Node(5);
        System.out.println(tree.isSubtree(root, subRoot));
        


    }

}