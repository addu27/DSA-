public class Star_Pattern {
    public static void main(String[] args) {
        /*
        // Star Pattern
        for (int i=0;i<4;i++){
            for (int j=0;j<=i;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
        */

        /*
        // Inverted Star
        for (int i = 0; i < 4; i++) {
            for (int j = i;j < 4;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
        */

        /*
        // Half_Pyramid pattern
        for (int i = 1; i <= 4 ; i++) {
            for (int j=1;j<=i;j++){
                System.out.print(j+" ");
            }
            System.out.println();
        }
        */

        /*
        // Print Character Pattern
        char ch = 'A';
        for (int i=1;i<=4;i++){
            for (int j=1;j<=i;j++){
                System.out.print(ch + " ");
                ch++;
            }
            System.out.println();
        }
        */

        /*
        // Hollow Rectangle pattern
        int totalRow = 4;
        int totalCol = 5;
         for (int i=1;i<=totalRow;i++){
             for (int j=1;j<=totalCol;j++){
                 if(i == 1 || i == totalRow || j == 1 || j == totalCol){
                     System.out.print("* ");
                 } else {
                     System.out.print("  ");
                 }
             }
             System.out.println();
         }
        */

        /*
        // Inverted and Rotated Half Pyramid
        int totCol = 4;
        int totRow = 4;
        int n = 4;

        for (int i = 1; i <= totRow ; i++) {
            for (int j=1;j<=(n-1);j++){
                System.out.print("  ");
            }
            n--;
            for (int j=1;j<=i;j++){
                System.out.print("* ");
            }
            System.out.println();
        }
        */

        /*
        // Inverted Half-Pyramid with numbers
        int totRow = 5;
        int totCol = 5;

        for (int i = totRow; i >= 1 ; i--) {
            for (int j = 1; j <= i; j++ ){
                System.out.print(j + " ");
            }
            System.out.println();
        }
        */

        /*
        // Floyd's Triangle
        int totRow = 5;
        int totCol = 5;
        int a = 1;
        for (int i = 1; i <= totRow; i++) {
            for (int j = 1; j <= i; j++){
                System.out.print(a + " ");
                a++;
            }
            System.out.println();
        }
        */

        /*
        // 0-1 Triangle
        for (int i = 1; i <= 5; i++) {
            for (int j = 1; j <= i; j++){
                if( (i+j) % 2 == 0){
                    System.out.print("0 ");
                } else {
                    System.out.print("1 ");
                }
            }
            System.out.println();
        }
        */

        /*
        // Butterfly Pattern
        int n = 4;

            // First Half
            for (int k = 1; k <= n; k++) {
                // For stars
                for (int j = 1; j <= k; j++){
                    System.out.print("* ");
                }
                // For Spaces
                for (int j = 1; j <= 2*(n-k); j++){
                    System.out.print("  ");
                }
                // For stars
                for (int j = 1; j <= k; j++){
                    System.out.print("* ");
                }

                System.out.println();
            }

            // Second Half
            for (int k = n; k >= 1; k--) {
                // For stars
                for (int j = k; j >= 1; j--){
                    System.out.print("* ");
                }
                // For Spaces
                for (int j = 1; j <= 2*(n-k); j++){
                    System.out.print("  ");
                }
                // For stars
                for (int j = k; j >= 1; j--){
                    System.out.print("* ");
                }

                System.out.println();
            }
         */

        /*
        // Solid Rhombus
        int s = 4;
        for (int i = 1; i <= 4 ; i++) {
            for (int j = 1; j <= (s-i); j++ ){
                System.out.print("  ");
            }
            for (int j = 1; j <= 4; j++){
                System.out.print("* ");
            }
            System.out.println();
        }
         */

        /*
        // Hollow Rhombus
        int totCol = 5;
        int totRow = 5;

        for (int i = 1; i <= totRow ; i++) {
            // for spaces
            for (int j = 1; j <= (totRow - i) ; j++) {
                System.out.print("  ");
            }
            // for stars
            for (int j = 1; j <= totCol; j++){
                if(i == 1 || j == 1 || i == totCol || j == totRow){
                    System.out.print("* ");
                }
                else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }

         */

        // Diamond Pattern
        int n = 4;
        for (int i = 1; i <= n ; i++) {
            // for spaces
            for (int j = 1; j <= (n-i) ; j++) {
                System.out.print("  ");
            }
            // for stars
            for (int j = 1; j <= (2* i) - 1 ; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
        for (int i = n; i >= 1 ; i--) {
            // for spaces
            for (int j = (n-i); j >= 1 ; j--) {
                System.out.print("  ");
            }
            // for stars
            for (int j = (2* i) - 1; j >= 1 ; j--) {
                System.out.print("* ");
            }
            System.out.println();
        }


    }
}
