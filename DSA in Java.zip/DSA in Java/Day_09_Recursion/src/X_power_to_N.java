// Print x to the power of n

public class X_power_to_N {

    public static int powerOf(int n, int pow){
        if (pow == 0){
            return 1;
        }
        return n * powerOf(n,pow-1);
    }

    // OPTIMIZED way
    public static int optimizedPowerOf(int n, int pow){
        if (pow == 0){
            return 1;
        }
        int halfPower = optimizedPowerOf(n, pow/2);
        int powerSqr = halfPower * halfPower;
        if (n % 2 != 0){
            return n * powerSqr;
        }
        return powerSqr;
    }

    public static void main(String[] args){
//        System.out.println(powerOf(5,3));
        System.out.println(optimizedPowerOf(5,3));
    }
}
