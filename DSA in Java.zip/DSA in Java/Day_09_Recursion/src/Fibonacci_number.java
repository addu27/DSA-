
// Print nth fibonacci number

public class Fibonacci_number {

    public static int fibonacciNum(int n){
        if (n == 0 || n == 1){
            return n;
        }
        return fibonacciNum(n-1) + fibonacciNum(n-2);
    }

    public static void main(String[] args){
        int n = 10;
        System.out.println(fibonacciNum(n));
    }
}
