
// Print numbers in increasing order

public class Print_num_increasing_order {

        public static void printDec(int n){
            if (n == 1){
                System.out.print(1 + " ");
                return;
            }
            printDec(n-1);
            System.out.print(n + " ");

        }

        public static void main(String[] args) {
            int n = 10;
            printDec(n);
        }
}
