public class Searching {

    public static int linearSearch(int arr[], int key){
        for (int i = 0; i < arr.length; i++) {
            if (key == arr[i]){
                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(int arr[], int key){
        int mid = arr.length / 2;
        int start = 0;
        int end = arr.length;

        while (start <= end){
            if(arr[mid] == key){
                return mid;
            } else if(arr[mid] < key){
                start = mid + 1;
                mid = (start + end) / 2;
            }else {
                end = mid -1;
                mid = (start + end) / 2;
            }
        }

        return -1;
    }

    public static void main(String[] args) {

        // linear search
//        int arr[] = {2,4,6,8,10,12};
//        int key = 10;
//        System.out.println(linearSearch(arr,key));

        // Binary Search
//        int arr[] = {2,4,6,8,10,12};
//        int key = 6;
//        System.out.println(binarySearch(arr,key));
    }
}
